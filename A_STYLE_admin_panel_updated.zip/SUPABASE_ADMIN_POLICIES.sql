-- A STYLE: run this AFTER the first database SQL.
-- It gives ONLY the admin email permission to manage store data.
-- Do not put a service_role/secret key in the browser.

-- Products
drop policy if exists "Admin can manage products" on public.products;
create policy "Admin can manage products"
on public.products
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Categories
drop policy if exists "Admin can manage categories" on public.categories;
create policy "Admin can manage categories"
on public.categories
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Product images
drop policy if exists "Admin can manage product images" on public.product_images;
create policy "Admin can manage product images"
on public.product_images
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Colors
drop policy if exists "Admin can manage colors" on public.colors;
create policy "Admin can manage colors"
on public.colors
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Sizes
drop policy if exists "Admin can manage sizes" on public.sizes;
create policy "Admin can manage sizes"
on public.sizes
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Variants
drop policy if exists "Admin can manage product variants" on public.product_variants;
create policy "Admin can manage product variants"
on public.product_variants
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Orders: admin can read/update, while the public insert policy remains.
drop policy if exists "Admin can manage orders" on public.orders;
create policy "Admin can manage orders"
on public.orders
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Order items
drop policy if exists "Admin can manage order items" on public.order_items;
create policy "Admin can manage order items"
on public.order_items
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Customers
drop policy if exists "Admin can manage customers" on public.customers;
create policy "Admin can manage customers"
on public.customers
for all
to authenticated
using ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com')
with check ((auth.jwt() ->> 'email') = 'hananamer871@gmail.com');

-- Storage: allow the admin to upload/update/delete product images.
drop policy if exists "Admin can upload product images" on storage.objects;
create policy "Admin can upload product images"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'products'
  and (auth.jwt() ->> 'email') = 'hananamer871@gmail.com'
);

drop policy if exists "Admin can update product images" on storage.objects;
create policy "Admin can update product images"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'products'
  and (auth.jwt() ->> 'email') = 'hananamer871@gmail.com'
)
with check (
  bucket_id = 'products'
  and (auth.jwt() ->> 'email') = 'hananamer871@gmail.com'
);

drop policy if exists "Admin can delete product images" on storage.objects;
create policy "Admin can delete product images"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'products'
  and (auth.jwt() ->> 'email') = 'hananamer871@gmail.com'
);