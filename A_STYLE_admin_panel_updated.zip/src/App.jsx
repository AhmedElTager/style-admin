import React, { useEffect, useMemo, useState } from "react";
import {
  Package, ShoppingBag, Plus, Search, LogOut, LayoutDashboard,
  Pencil, Trash2, Upload, X, Menu, RefreshCw
} from "lucide-react";
import { supabase } from "./supabase";

const ADMIN_EMAIL = "hananamer871@gmail.com";
const emptyForm = {
  name: "", slug: "", description: "", price: "", old_price: "",
  category_id: "", stock: 0, is_active: true, is_featured: false,
  main_image: ""
};

function money(v) {
  return `${Number(v || 0).toLocaleString("ar-EG")} ج.م`;
}

function slugify(text) {
  return text.trim().toLowerCase()
    .replace(/[^\u0600-\u06FF\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-") || `product-${Date.now()}`;
}

export default function App() {
  const [session, setSession] = useState(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setChecking(false);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  if (checking) return <Splash />;
  if (!session) return <Login />;
  if (session.user.email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
    return <Unauthorized />;
  }
  return <Dashboard />;
}

function Splash() {
  return <div className="splash"><img src="/a-style-logo.jpg" /><p>جاري تحميل لوحة التحكم...</p></div>;
}

function Login() {
  const [email, setEmail] = useState(ADMIN_EMAIL);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function login(e) {
    e.preventDefault();
    setBusy(true); setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError("الإيميل أو كلمة المرور غير صحيحة.");
    setBusy(false);
  }

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={login}>
        <img src="/a-style-logo.jpg" className="auth-logo" />
        <h1>A STYLE</h1>
        <p>تسجيل دخول لوحة التحكم</p>
        <label>البريد الإلكتروني</label>
        <input value={email} onChange={e => setEmail(e.target.value)} type="email" required />
        <label>كلمة المرور</label>
        <input value={password} onChange={e => setPassword(e.target.value)} type="password" required />
        {error && <div className="error">{error}</div>}
        <button className="primary wide" disabled={busy}>{busy ? "جاري الدخول..." : "دخول"}</button>
      </form>
    </main>
  );
}

function Unauthorized() {
  return (
    <main className="auth-page">
      <div className="auth-card">
        <img src="/a-style-logo.jpg" className="auth-logo" />
        <h2>هذا الحساب غير مصرح له</h2>
        <p>استخدمي حساب الإدارة المخصص لـ A STYLE.</p>
        <button className="secondary wide" onClick={() => supabase.auth.signOut()}>تسجيل الخروج</button>
      </div>
    </main>
  );
}

function Dashboard() {
  const [tab, setTab] = useState("overview");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  async function loadAll() {
    setLoading(true);
    const [p, c, o] = await Promise.all([
      supabase.from("products").select("*, categories(name)").order("created_at", { ascending: false }),
      supabase.from("categories").select("*").order("sort_order"),
      supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(100)
    ]);
    if (p.error) alert(p.error.message);
    setProducts(p.data || []);
    setCategories(c.data || []);
    setOrders(o.data || []);
    setLoading(false);
  }

  useEffect(() => { loadAll(); }, []);

  async function logout() { await supabase.auth.signOut(); }

  const stats = useMemo(() => ({
    products: products.length,
    active: products.filter(p => p.is_active).length,
    orders: orders.length,
    pending: orders.filter(o => o.status === "pending").length
  }), [products, orders]);

  async function deleteProduct(id) {
    if (!confirm("هل تريدين حذف المنتج نهائيًا؟")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return alert(error.message);
    await loadAll();
  }

  async function updateOrder(id, status) {
    const { error } = await supabase.from("orders").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) alert(error.message);
    else loadAll();
  }

  return (
    <div className="app-shell">
      <aside className={mobileMenu ? "sidebar open" : "sidebar"}>
        <div className="brand">
          <img src="/a-style-logo.jpg" />
          <div><strong>A STYLE</strong><span>ADMIN PANEL</span></div>
        </div>
        <nav>
          <NavButton icon={<LayoutDashboard />} text="الرئيسية" active={tab==="overview"} onClick={() => {setTab("overview");setMobileMenu(false)}} />
          <NavButton icon={<Package />} text="المنتجات" active={tab==="products"} onClick={() => {setTab("products");setMobileMenu(false)}} />
          <NavButton icon={<ShoppingBag />} text="الطلبات" active={tab==="orders"} onClick={() => {setTab("orders");setMobileMenu(false)}} />
        </nav>
        <button className="logout" onClick={logout}><LogOut /> تسجيل الخروج</button>
      </aside>

      {mobileMenu && <div className="backdrop" onClick={() => setMobileMenu(false)} />}
      <section className="main">
        <header className="topbar">
          <button className="icon-btn mobile-only" onClick={() => setMobileMenu(true)}><Menu /></button>
          <div><h1>{tab==="overview" ? "لوحة التحكم" : tab==="products" ? "المنتجات" : "الطلبات"}</h1><span>إدارة متجر A STYLE</span></div>
          <button className="icon-btn" onClick={loadAll} title="تحديث"><RefreshCw /></button>
        </header>

        {tab === "overview" && <Overview stats={stats} products={products} setTab={setTab} />}
        {tab === "products" && (
          <Products products={products} categories={categories} loading={loading}
            onAdd={() => setEditing({ ...emptyForm })}
            onEdit={p => setEditing({ ...p })}
            onDelete={deleteProduct} />
        )}
        {tab === "orders" && <Orders orders={orders} onUpdate={updateOrder} />}
      </section>

      {editing && <ProductModal product={editing} categories={categories} onClose={() => setEditing(null)} onSaved={() => {setEditing(null);loadAll();}} />}
    </div>
  );
}

function NavButton({ icon, text, active, onClick }) {
  return <button className={active ? "nav-btn active" : "nav-btn"} onClick={onClick}>{icon}<span>{text}</span></button>;
}

function Overview({ stats, products, setTab }) {
  return (
    <div className="content">
      <div className="stats">
        <Stat icon={<Package />} label="إجمالي المنتجات" value={stats.products} />
        <Stat icon={<Package />} label="منتجات ظاهرة" value={stats.active} />
        <Stat icon={<ShoppingBag />} label="كل الطلبات" value={stats.orders} />
        <Stat icon={<ShoppingBag />} label="طلبات معلقة" value={stats.pending} />
      </div>
      <div className="section-head"><div><h2>آخر المنتجات</h2><p>يمكنك إدارة المنتجات من هنا.</p></div><button className="primary" onClick={() => setTab("products")}><Package /> إدارة المنتجات</button></div>
      <div className="product-grid">
        {products.slice(0, 8).map(p => <ProductCard key={p.id} p={p} />)}
        {!products.length && <Empty text="لم تتم إضافة منتجات بعد." />}
      </div>
    </div>
  );
}

function Stat({ icon, label, value }) {
  return <div className="stat"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong></div></div>;
}

function Products({ products, categories, loading, onAdd, onEdit, onDelete }) {
  const [q, setQ] = useState("");
  const filtered = products.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="content">
      <div className="toolbar">
        <div className="search"><Search /><input value={q} onChange={e=>setQ(e.target.value)} placeholder="ابحثي عن منتج..." /></div>
        <button className="primary" onClick={onAdd}><Plus /> إضافة منتج</button>
      </div>
      {loading ? <Empty text="جاري التحميل..." /> : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>المنتج</th><th>القسم</th><th>السعر</th><th>المخزون</th><th>الحالة</th><th>إجراءات</th></tr></thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id}>
                  <td><div className="product-name"><img src={p.main_image || "/a-style-logo.jpg"} /><span>{p.name}</span></div></td>
                  <td>{p.categories?.name || "بدون قسم"}</td>
                  <td>{money(p.price)}</td>
                  <td>{p.stock}</td>
                  <td><span className={p.is_active ? "badge ok" : "badge"}>{p.is_active ? "ظاهر" : "مخفي"}</span></td>
                  <td><div className="actions"><button className="small" onClick={()=>onEdit(p)}><Pencil /></button><button className="small danger" onClick={()=>onDelete(p.id)}><Trash2 /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filtered.length && <Empty text="لا توجد منتجات." />}
        </div>
      )}
    </div>
  );
}

function ProductCard({ p }) {
  return <div className="mini-card"><img src={p.main_image || "/a-style-logo.jpg"} /><div><strong>{p.name}</strong><span>{money(p.price)}</span></div></div>;
}

function Orders({ orders, onUpdate }) {
  return (
    <div className="content">
      <div className="order-list">
        {orders.map(o => (
          <div className="order-card" key={o.id}>
            <div><strong>طلب #{o.id.slice(0,8)}</strong><span>{o.customer_name} — {o.phone}</span><small>{new Date(o.created_at).toLocaleString("ar-EG")}</small></div>
            <div><strong>{money(o.total)}</strong><select value={o.status || "pending"} onChange={e=>onUpdate(o.id,e.target.value)}>
              <option value="pending">معلق</option><option value="confirmed">مؤكد</option><option value="shipped">تم الشحن</option><option value="delivered">تم التسليم</option><option value="cancelled">ملغي</option>
            </select></div>
          </div>
        ))}
        {!orders.length && <Empty text="لا توجد طلبات حتى الآن." />}
      </div>
    </div>
  );
}

function ProductModal({ product, categories, onClose, onSaved }) {
  const [form, setForm] = useState({
    ...emptyForm,
    ...product,
    price: product.price ?? "",
    old_price: product.old_price ?? "",
    stock: product.stock ?? 0,
    category_id: product.category_id ?? ""
  });
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(product.main_image || "");
  const [busy, setBusy] = useState(false);

  function set(k, v) { setForm(f => ({...f, [k]: v})); }

  async function uploadImage(file) {
    const ext = file.name.split(".").pop().toLowerCase();
    const path = `products/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("products").upload(path, file, { upsert: false, contentType: file.type });
    if (error) throw error;
    const { data } = supabase.storage.from("products").getPublicUrl(path);
    return data.publicUrl;
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    try {
      let image = form.main_image;
      if (file) image = await uploadImage(file);
      const payload = {
        name: form.name.trim(),
        slug: (form.slug || slugify(form.name)).trim(),
        description: form.description || null,
        price: Number(form.price || 0),
        old_price: form.old_price ? Number(form.old_price) : null,
        category_id: form.category_id || null,
        main_image: image || null,
        stock: Number(form.stock || 0),
        is_active: !!form.is_active,
        is_featured: !!form.is_featured,
        updated_at: new Date().toISOString()
      };
      let result;
      if (product.id) result = await supabase.from("products").update(payload).eq("id", product.id);
      else result = await supabase.from("products").insert(payload);
      if (result.error) throw result.error;
      onSaved();
    } catch (err) {
      alert(err.message || "حدث خطأ.");
    } finally { setBusy(false); }
  }

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <div className="modal-head"><div><h2>{product.id ? "تعديل المنتج" : "إضافة منتج جديد"}</h2><span>كل البيانات من لوحة التحكم فقط</span></div><button className="icon-btn" onClick={onClose}><X /></button></div>
        <form onSubmit={save}>
          <div className="modal-grid">
            <div>
              <label>اسم المنتج *</label><input required value={form.name} onChange={e=>set("name",e.target.value)} placeholder="مثال: طقم صيفي حريمي" />
              <label>الرابط المختصر</label><input value={form.slug} onChange={e=>set("slug",e.target.value)} placeholder="يتم إنشاؤه تلقائيًا" />
              <label>القسم</label><select value={form.category_id} onChange={e=>set("category_id",e.target.value)}><option value="">بدون قسم</option>{categories.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
              <div className="two"><div><label>السعر *</label><input required type="number" min="0" step="0.01" value={form.price} onChange={e=>set("price",e.target.value)} /></div><div><label>السعر القديم</label><input type="number" min="0" step="0.01" value={form.old_price} onChange={e=>set("old_price",e.target.value)} /></div></div>
              <label>المخزون</label><input type="number" min="0" value={form.stock} onChange={e=>set("stock",e.target.value)} />
              <label>الوصف</label><textarea rows="5" value={form.description || ""} onChange={e=>set("description",e.target.value)} />
              <div className="checks"><label><input type="checkbox" checked={form.is_active} onChange={e=>set("is_active",e.target.checked)} /> إظهار المنتج في المتجر</label><label><input type="checkbox" checked={form.is_featured} onChange={e=>set("is_featured",e.target.checked)} /> منتج مميز</label></div>
            </div>
            <div>
              <label>صورة المنتج</label>
              <label className="upload-box">
                {preview ? <img src={preview} /> : <><Upload /><span>اضغطي لاختيار صورة من الموبايل</span></>}
                <input type="file" accept="image/*" hidden onChange={e=>{const f=e.target.files?.[0]; if(f){setFile(f);setPreview(URL.createObjectURL(f));}}} />
              </label>
              {preview && <button type="button" className="secondary wide" onClick={()=>{setFile(null);setPreview("");set("main_image","")}}>حذف الصورة</button>}
            </div>
          </div>
          <div className="modal-actions"><button type="button" className="secondary" onClick={onClose}>إلغاء</button><button className="primary" disabled={busy}>{busy ? "جاري الحفظ..." : "حفظ المنتج"}</button></div>
        </form>
      </div>
    </div>
  );
}

function Empty({ text }) { return <div className="empty"><Package /><p>{text}</p></div>; }