# A STYLE — لوحة التحكم

هذه نسخة بداية جاهزة للوحة تحكم متجر A STYLE.

## تشغيل محليًا

1. انسخي `.env.example` إلى `.env`.
2. ضعي Project URL و Publishable Key في `.env`.
3. شغلي:
   `npm install`
   ثم:
   `npm run dev`

## Supabase

بعد قاعدة البيانات الأساسية، شغّلي ملف `SUPABASE_ADMIN_POLICIES.sql` في SQL Editor.

حساب الإدارة المسموح له هو:
`hananamer871@gmail.com`

لا تضعي Secret/Service Role key في `.env` الخاص بالمتصفح.

## النشر على Vercel

ارفعِي المشروع إلى GitHub ثم اربطي المستودع بـ Vercel، وضعي:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`

في Environment Variables.

## ملاحظات

النسخة الحالية تحتوي على:
- تسجيل دخول الإدارة
- لوحة إحصائيات
- إضافة/تعديل/حذف المنتجات
- رفع صورة المنتج من الموبايل إلى Supabase Storage
- الأقسام
- المخزون
- الطلبات وتغيير حالتها

واجهة المتجر نفسها ستُربط بالمنتجات بعد الانتهاء من لوحة التحكم.
